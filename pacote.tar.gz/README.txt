Desenvolvimento de modulo para porteiro eletrônico via VoIP

Desenvolvedor: Victor "SlowHusky" Pires

Ferramentas: PHP, ZendPHP, HTML, SNEP
